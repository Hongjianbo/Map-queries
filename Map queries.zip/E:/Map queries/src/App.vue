<script setup>
import MapContainer from "./components/MapContainer.vue";
</script>

<template>
  <MapContainer />
</template>
